package utilities;

import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import java.util.Map;

import static io.restassured.RestAssured.given;

public class APIUtils {

    public static AllureRestAssured requestSpecification;

    // Common GET method
    public static Response getRequest(String endpoint) {
        return given()
                .header("Content-Type", "application/json")
                .when()
                .get(endpoint)
                .then()
                .extract()
                .response();
    }
    /**
     * Sends a GET request with optional headers and query parameters.
     *
     * @param endpoint     The API endpoint URL.
     * @param headers      A map containing any headers to include in the request (optional).
     * @param queryParams  A map containing any query parameters to include in the request (optional).
     * @return Response    The response from the server.
     */
    public static Response getRequestWithParams(String endpoint, Map<String, String> headers, Map<String, Object> queryParams) {

        // Initialize request specification
        RestAssured.requestSpecification = given();

        // Add default or custom headers
        if (headers != null && !headers.isEmpty()) {
            RestAssured.requestSpecification.headers(headers);
        } else {
            // Add default Content-Type header if not provided
            RestAssured.requestSpecification.header("Content-Type", "application/json");
        }

        // Add query parameters if provided
        if (queryParams != null && !queryParams.isEmpty()) {
            RestAssured.requestSpecification.queryParams(queryParams);
        }

        // Send the GET request and extract the response
        return RestAssured.requestSpecification
                .when()
                .get(endpoint)
                .then()
                .extract()
                .response();
    }

    // Common POST method
    /**
     * Sends a POST request with optional headers, query parameters, and a request body.
     *
     * @param endpoint     The API endpoint URL.
     * @param headers      A map containing any headers to include in the request (optional).
     * @param queryParams  A map containing any query parameters to include in the request (optional).
     * @param body         The request body (JSON String). If null or empty, no body will be sent.
     * @return Response    The response from the server.
     */
    public static Response postRequestWithParams(String endpoint,String param, Map<String, String> headers,
                                       Map<String, Object> queryParams, String body) {

        // Initialize request specification
        RestAssured.requestSpecification = given();

        // Add default or custom headers
        if (headers != null && !headers.isEmpty()) {
            RestAssured.requestSpecification.headers(headers);
        } else {
            // Add default Content-Type header if not provided
            RestAssured.requestSpecification.header("Content-Type", "application/json");
        }

        // Add query parameters if provided
        if (queryParams != null && !queryParams.isEmpty()) {
            RestAssured.requestSpecification.queryParams(queryParams);
        }

        // Add body only if it's not null or empty
        if (body != null && !body.isEmpty()) {
            RestAssured.requestSpecification.body(body);
        }

        // Send the POST request and extract the response
        return RestAssured.requestSpecification
                .when()
                .post(endpoint)
                .then()
                .extract()
                .response();
    }

    public static Response postRequest(String endpoint, String body) {
        return given()
                .header("Content-Type", "application/json")
                .body(body)
                .when()
                .post(endpoint)
                .then()
                .extract()
                .response();
    }

    // Common PUT method
    public static Response putRequest(String endpoint, String body) {
        return given()
                .header("Content-Type", "application/json")
                .body(body)
                .when()
                .put(endpoint)
                .then()
                .extract()
                .response();
    }

    /**
     * Sends a PUT request with optional headers, query parameters, and a request body.
     *
     * @param endpoint     The API endpoint URL.
     * @param headers      A map containing any headers to include in the request (optional).
     * @param queryParams  A map containing any query parameters to include in the request (optional).
     * @param body         The request body (JSON String). If null or empty, no body will be sent.
     * @return Response    The response from the server.
     */
    public static Response putRequestWithParams(String endpoint, Map<String, String> headers,
                                      Map<String, Object> queryParams, String body) {

        // Initialize request specification
        RestAssured.requestSpecification = given();

        // Add default or custom headers
        if (headers != null && !headers.isEmpty()) {
            RestAssured.requestSpecification.headers(headers);
        } else {
            // Add default Content-Type header if not provided
            RestAssured.requestSpecification.header("Content-Type", "application/json");
        }

        // Add query parameters if provided
        if (queryParams != null && !queryParams.isEmpty()) {
            RestAssured.requestSpecification.queryParams(queryParams);
        }

        // Add body only if it's not null or empty
        if (body != null && !body.isEmpty()) {
            RestAssured.requestSpecification.body(body);
        }

        // Send the PUT request and extract the response
        return RestAssured.requestSpecification
                .when()
                .put(endpoint)
                .then()
                .extract()
                .response();
    }

    // Common DELETE method
    public static Response deleteRequest(String endpoint) {
        return given()
                .header("Content-Type", "application/json")
                .when()
                .delete(endpoint)
                .then()
                .extract()
                .response();
    }

    /**
     * Sends a DELETE request with optional headers and query parameters.
     *
     * @param endpoint     The API endpoint URL.
     * @param headers      A map containing any headers to include in the request (optional).
     * @param queryParams  A map containing any query parameters to include in the request (optional).
     * @return Response    The response from the server.
     */
    public static Response deleteRequestWithParams(String endpoint, Map<String, String> headers,
                                         Map<String, Object> queryParams) {

        // Initialize request specification
        RestAssured.requestSpecification = given();

        // Add default or custom headers
        if (headers != null && !headers.isEmpty()) {
            RestAssured.requestSpecification.headers(headers);
        } else {
            // Add default Content-Type header if not provided
            RestAssured.requestSpecification.header("Content-Type", "application/json");
        }

        // Add query parameters if provided
        if (queryParams != null && !queryParams.isEmpty()) {
            RestAssured.requestSpecification.queryParams(queryParams);
        }

        // Send the DELETE request and extract the response
        return RestAssured.requestSpecification
                .when()
                .delete(endpoint)
                .then()
                .extract()
                .response();
    }
    // Common PATCH method
    public static Response patchRequest(String endpoint, String body) {
        return given()
                .header("Content-Type", "application/json")
                .body(body)
                .when()
                .patch(endpoint)
                .then()
                .extract()
                .response();
    }
    /**
     * Sends a PATCH request with optional headers, query parameters, and a request body.
     *
     * @param endpoint     The API endpoint URL.
     * @param headers      A map containing any headers to include in the request (optional).
     * @param queryParams  A map containing any query parameters to include in the request (optional).
     * @param body         The request body (JSON String). If null or empty, no body will be sent.
     * @return Response    The response from the server.
     */
    public static Response patchRequestWithParams(String endpoint, Map<String, String> headers,
                                        Map<String, Object> queryParams, String body) {

        // Initialize request specification
        RestAssured.requestSpecification = given();

        // Add default or custom headers
        if (headers != null && !headers.isEmpty()) {
            RestAssured.requestSpecification.headers(headers);
        } else {
            // Add default Content-Type header if not provided
            RestAssured.requestSpecification.header("Content-Type", "application/json");
        }

        // Add query parameters if provided
        if (queryParams != null && !queryParams.isEmpty()) {
            RestAssured.requestSpecification.queryParams(queryParams);
        }

        // Add body only if it's not null or empty
        if (body != null && !body.isEmpty()) {
            RestAssured.requestSpecification.body(body);
        }

        // Send the PATCH request and extract the response
        return RestAssured.requestSpecification
                .when()
                .patch(endpoint)
                .then()
                .extract()
                .response();
    }
}
