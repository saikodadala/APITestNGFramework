package utilities;

import io.restassured.response.Response;

public class Utilities {
    // Method to print response details
    public static void printResponseDetails(Response response) {
        System.out.println("Response Code: " + response.getStatusCode());
        System.out.println("Response Body: " + response.getBody().asString());
    }
}
