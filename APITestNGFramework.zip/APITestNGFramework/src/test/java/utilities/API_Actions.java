package utilities;

import com.aventstack.extentreports.ExtentTest;
import io.restassured.response.Response;
import org.testng.Assert;

public class API_Actions {

    public static void getAssertions(ExtentTest test, Response response){
        test.info("GET Response: " + response.asString());
        Assert.assertEquals(response.getStatusCode(), 200);
        test.pass("GET request passed");
    }

    public static void postAssertions(ExtentTest test, Response response){
        test.info("POST Response: " + response.asString());
        Assert.assertEquals(response.getStatusCode(), 201);
        test.pass("POST request passed");
    }
}
