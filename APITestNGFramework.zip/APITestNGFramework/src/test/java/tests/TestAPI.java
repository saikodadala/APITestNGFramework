package tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import utilities.APIUtils;
import utilities.API_Actions;
import utilities.ExtentManager;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import static config.Config.baseUrl;
import static config.params.getRequest;

public class TestAPI {

    private ExtentReports extent;
    private ExtentTest test;

    String jsonFile = "src/test/java/config/jsonData.json";

    @BeforeSuite
    public void setup() {
        // Initialize ExtentReports
        extent = ExtentManager.getInstance();
    }

    @Test
    public void testGetRequest() {
        test = extent.createTest("testGetRequest", "Verify GET request");
        Response response = APIUtils.getRequest(baseUrl + getRequest);
        API_Actions.getAssertions(test,response);
    }

    @Test
    public void testPostRequest() throws IOException {
        test = extent.createTest("testPostRequest", "Verify POST request");
        String jsonBody = new String(Files.readAllBytes(Paths.get(jsonFile)));
        Map<String, Object> queryParams = new HashMap<>();  // Empty map        // Empty headers map
        Map<String, String> headers = new HashMap<>();  // Empty map
        Response response = APIUtils.postRequest(baseUrl, "/posts",headers,queryParams,jsonBody);
        API_Actions.postAssertions(test,response);
    }

    @AfterSuite
    public void tearDown() {
        // Generate Extent report
        extent.flush();
    }
}
