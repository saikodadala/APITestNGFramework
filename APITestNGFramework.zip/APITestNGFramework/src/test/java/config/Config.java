package config;

public class Config {
    public static final String baseUrl = "https://jsonplaceholder.typicode.com";  // Example API
}
