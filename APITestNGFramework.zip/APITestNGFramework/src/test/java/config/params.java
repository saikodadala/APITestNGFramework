package config;

public class params {
    public static final String getRequest = "/posts/1";  // Example API
}
